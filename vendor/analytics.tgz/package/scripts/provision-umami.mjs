#!/usr/bin/env node
/**
 * Provision a new website in the central Umami instance and print its websiteId.
 * Adopting a project = run this once, then mount <UmamiScript websiteId="..."/>.
 *
 * Usage:
 *   node scripts/provision-umami.mjs --name "etutor.ro" --domain etutor.ro
 *
 * Credentials: reads Master/credentials/techbiz-analytics.env (UMAMI_URL,
 * UMAMI_ADMIN_USER, UMAMI_ADMIN_PASS) or the same three vars from process.env.
 * The env file is parsed line-by-line (NEVER `source`d — passwords contain
 * shell metacharacters).
 */
import { readFileSync, existsSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

function parseArgs() {
  const a = process.argv.slice(2)
  const get = (flag) => { const i = a.indexOf(flag); return i >= 0 ? a[i + 1] : undefined }
  return { name: get('--name'), domain: get('--domain'), envFile: get('--env-file') }
}

function loadCreds(envFile) {
  const candidates = [
    envFile,
    process.env.TECHBIZ_ANALYTICS_ENV,
    join(homedir(), 'Projects', 'Master', 'credentials', 'techbiz-analytics.env'),
    'C:/Projects/Master/credentials/techbiz-analytics.env',
  ].filter(Boolean)
  const out = {
    url: process.env.UMAMI_URL,
    user: process.env.UMAMI_ADMIN_USER,
    pass: process.env.UMAMI_ADMIN_PASS,
  }
  if (out.url && out.user && out.pass) return out
  for (const p of candidates) {
    if (!existsSync(p)) continue
    for (const line of readFileSync(p, 'utf8').split('\n')) {
      const m = line.match(/^(UMAMI_URL|UMAMI_ADMIN_USER|UMAMI_ADMIN_PASS)=(.*)$/)
      if (!m) continue
      const v = m[2].trim()
      if (m[1] === 'UMAMI_URL' && !out.url) out.url = v
      if (m[1] === 'UMAMI_ADMIN_USER' && !out.user) out.user = v
      if (m[1] === 'UMAMI_ADMIN_PASS' && !out.pass) out.pass = v
    }
    if (out.url && out.user && out.pass) return out
  }
  return out
}

const { name, domain, envFile } = parseArgs()
if (!name || !domain) {
  console.error('Usage: node scripts/provision-umami.mjs --name "<display name>" --domain <host> [--env-file <path>]')
  process.exit(1)
}
const creds = loadCreds(envFile)
if (!creds.url || !creds.user || !creds.pass) {
  console.error('Missing Umami credentials (UMAMI_URL / UMAMI_ADMIN_USER / UMAMI_ADMIN_PASS).')
  process.exit(1)
}

const api = async (method, path, body, token) => {
  const res = await fetch(`${creds.url}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  })
  const text = await res.text()
  let json
  try { json = JSON.parse(text) } catch { json = { raw: text.slice(0, 120) } }
  return { status: res.status, json }
}

const login = await api('POST', '/api/auth/login', { username: creds.user, password: creds.pass })
if (login.status !== 200) {
  console.error(`Umami login failed (${login.status}).`)
  process.exit(1)
}
const token = login.json.token

// Reuse an existing site for the same domain instead of duplicating.
const list = await api('GET', '/api/websites', undefined, token)
const existing = (list.json?.data ?? []).find((w) => w.domain === domain)
if (existing) {
  console.log(`Website already provisioned: ${domain}`)
  console.log(`websiteId=${existing.id}`)
  process.exit(0)
}

const created = await api('POST', '/api/websites', { name, domain }, token)
if (created.status !== 200 && created.status !== 201) {
  console.error(`Create failed (${created.status}):`, JSON.stringify(created.json).slice(0, 200))
  process.exit(1)
}
console.log(`Website provisioned: ${name} (${domain})`)
console.log(`websiteId=${created.json.id}`)
console.log('\nNext: mount in the project layout:')
console.log(`  <UmamiScript websiteId="${created.json.id}" />`)
console.log('and allow the Umami origin in the project CSP (see umamiCsp()).')
